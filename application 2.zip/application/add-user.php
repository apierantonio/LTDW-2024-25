<?php
    foreach($_POST as $key => $value) {
        echo "{$key}: {$value}<br>";
    }
?>